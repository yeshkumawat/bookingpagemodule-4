from django.urls import path
from django.contrib import admin
from doctorapp import views

urlpatterns = [
    path("",views.home),
    path("datetime",views.datetime)
  
]